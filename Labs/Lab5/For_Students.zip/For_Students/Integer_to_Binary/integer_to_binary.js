function toBinary( n, a )
{
	// you code goes here
}


