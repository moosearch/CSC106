var nSwaps = 0;
var nComparisons = 0;
var nSpace = 10;

function insertionSort( a )
{
	// your code goes here
}

