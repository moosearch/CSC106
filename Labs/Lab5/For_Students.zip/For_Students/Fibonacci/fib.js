function fibonacci( n )
{
	// your code goes here
}

var table = [0,1];

function fibonacci2(n)
{
	// your code goes here
}