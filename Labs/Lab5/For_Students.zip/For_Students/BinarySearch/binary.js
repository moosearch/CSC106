var nComp = 0;

function binarySearch( a, lookFor )
{
	var high = a.length - 1;
	var low = 0;
	var mid = Math.floor( (high + low) / 2 );

	while ( low <= high ){
		// your code goes here
		++nComp;
	}
	return -1;
}

function linearSearch( a, lookFor )
{
	for (var i = 0; i < a.length; ++i) {
		++nComp;
		// your code goes here
	}
	return -1;
}


