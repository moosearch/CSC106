var nSwaps = 0;
var nComparisons = 0;
var nSpace = 10;


function quicksort( a )
{
	//your code goes here
}

function quicksort_in_place( a, low_index, high_index )
{
	// your code goes here
}



