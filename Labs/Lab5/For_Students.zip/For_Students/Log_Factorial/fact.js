function log_factorial( n )
{
	// your code goes here
}


